from agentforge.agent import Agent


class DocsAgent(Agent):
    pass
