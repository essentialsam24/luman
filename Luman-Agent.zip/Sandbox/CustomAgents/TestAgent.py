from agentforge.agent import Agent


class TestAgent(Agent):
    pass
