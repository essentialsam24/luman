from agentforge.agent import Agent


class TestoAgent(Agent):
    pass
