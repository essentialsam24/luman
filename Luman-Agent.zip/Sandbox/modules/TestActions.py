from agentforge.modules.Actions import Action

test = Action()
