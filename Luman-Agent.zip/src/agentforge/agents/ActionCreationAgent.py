from agentforge.agent import Agent


class ActionCreationAgent(Agent):
    pass
