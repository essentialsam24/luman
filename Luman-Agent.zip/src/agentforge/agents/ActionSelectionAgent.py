from agentforge.agent import Agent


class ActionSelectionAgent(Agent):
    pass
