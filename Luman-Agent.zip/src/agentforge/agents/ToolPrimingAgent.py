from agentforge.agent import Agent


class ToolPrimingAgent(Agent):
    pass
